<?php
/**
 * Plugin Name: Pruebas
 * Plugin Uri: https://thewparchitect.com/
 * Description: Este es un plugin de Pruebas.
 * Version: 1.0.0
 * Requires PHP: 7.0
 * Author: The WP Arquitect
 * Author Uri: https://www.linkedin.com/in/josue-baldizon-4b1830131/
 * License: GPL V2
 * License Uri: https://wwww.gmu.org/licenses/gpl-2.0.html
 * Text Domain: Pruebas
 * Domain Path: /languages
 */


 
 

 function res_desactivacion() {

    //Accion
    //flush_rewrite_rules();


 }
 register_deactivation_hook(__FILE__, 'res_desactivacion');

 

if( !isset( $mivariable ) ){

   $mivariable = "Nuevo valor";


}


if( !function_exists( 'res_install' ) ){

   function res_install(){

  //Accion
  require_once 'activador.php';
  
  
   }

   register_activation_hook( __FILE__, 'res_install' );

}

if( !class_exists( 'RES_MI_Class' ) ){

   class RES_MI_Class{


   }


}

if( !function_exists( 'res_plugins_cargados' ) ){

   function res_plugins_cargados(){

     if( current_user_can( 'edit_pages' ) ){

         if( !function_exists( 'add_meta_description' ) ){

          function add_meta_description(){

            echo "<meta name='description' content='Creacion de plugins de WordPress'>";
              

          } 

          add_action( 'wp_head', 'add_meta_description' );


         }


     }

   }

   add_action( 'plugins_loaded', 'res_plugins_cargados' );

}

if( !function_exists( 'res_prueba_nonce' ) ){


   function res_prueba_nonce(){

       add_menu_page(
           'RES Prueba Nonce',
           'RES Prueba Nonce',
           'manage_options',
           'res_pruebas_nonce',
           'res_pruebas_page_display',
           'dashicons-welcome-learn-more',
           '15'

       );

        remove_menu_page('res_pruebas_nonce');

   }

  add_action( 'admin_menu', 'res_prueba_nonce' );

  


}


if( !function_exists( 'res_pruebas_page_display' ) ){

   function res_pruebas_page_display(){

     if( current_user_can( 'edit_others_posts' ) ){

        $nonce = wp_create_nonce( 'mi_nonce_de_seguridad' );

             echo "<br> $nonce <br>";

             if( isset( $_POST['nonce'] ) && !empty( $_POST['nonce'] ) ){

               if( wp_verify_nonce( $_POST['nonce'], 'mi_nonce_de_seguridad' ) ){

                  echo "Hemos verificado correctamente el nonce recibido <br> Nonce : {$_POST['nonce']} <br>";
                



               }else{

                  echo "El nonce no fue recibido o no es correcto";

               }

             }

        
      ?>

      <br>
      <form action="" method="post">

         <input type="hidden" name="nonce" value="<?php echo $nonce; ?>">

         <input type="hidden" name="eliminar" value="eliminar">

         <button type="submit">Eliminar</button>

      </form>

      <?php

     }   

   
    } 

} 



if( !function_exists( 'res_options_page' ) ){
   function res_options_page(){
   add_menu_page(
   'RES Opciones de Página',
   'RES Opciones de Página',
   'manage_options',
   'res_options_page',
   'res_options_page_display',
   //ruta raíz del plugin
   plugin_dir_url( __FILE__ ) . 'img/icono_personalizado.png',
   '15'
   );

     add_submenu_page(
        'res_options_page',
        'Submenu 1',
        'Submenu 1',
        'manage_options',
        'res_submenu1_pruebas',
        'res_submenu1_pruebas_display'    
        


     );

   }
   add_action( 'admin_menu', 'res_options_page' );

}


if( !function_exists( 'res_options_page_display' ) ){
   function res_options_page_display(){
   ?>
   <!--html-->
   <div class="wrap">
   <form action="" method="post">
   <input type="text" placeholder="Texto" name="" id="">
   <?php submit_button( 'Enviar' ); ?>
   </form>
   </div>
   <?php
   }
  }


if( !function_exists( 'res_submenu1_pruebas_display' ) ){

function res_submenu1_pruebas_display(){
       
   ?>

   <!--html-->

   <div class="wrap">

   <h3>Bienvenido a la pagina submenu</h3>

   </div>

   <?php

}

}



//Funcion eliminar widget

function miprimerafuncion(){

 unregister_widget( 'WP_Widget_Calendar' );

}

add_action( 'widgets_init', 'miprimerafuncion' );

//Funcion para enviar email al crear un post

function function_callback_save_post( $post_id, $post ){
   if( wp_is_post_revision( $post_id ) ){
   return;
   }
   $autor_id = $post->post_author;
   $name_autor = get_the_author_meta( 'display_name', $autor_id );
   $email_autor = get_the_author_meta( 'user_email', $autor_id );
   $title = $post->post_title;
   $permalink = get_permalink( $post_id );
   //Datos para el email
   $para = sprintf( '%s', $email_autor );
   $asunto = sprintf( 'Publicación guardada: %s', $title );
   $mensaje = sprintf( 'Felicitaciones, %s! su publicación "%s" ha sido
  guardada,
   puede verlo en el siguiente enlace: %s', $name_autor, $title, $permal
  ink );
   $headers[] = 'From: "' . $name_autor . '" < ' . get_option('admin_ema
  il') . ' >';
   wp_mail( $para, $asunto, $mensaje, $headers );
  }
  add_action( 'save_post', 'function_callback_save_post', 10, 2 );