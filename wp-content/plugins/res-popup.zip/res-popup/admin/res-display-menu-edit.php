<?php

$nombre = $_GET['edit'];
$id = $_GET['id'];

echo "Hola esta es la pagina para editar el pop-up <h1>$nombre</h1> con el id <h1>$id</h1>";



