<?php 

/**
 * Aqui pondremos alguna acción al activar el plugin
 */